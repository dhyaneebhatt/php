<?php

    if ($_SERVER["REQUEST_METHOD"] == "POST") 
	{

        // 1. UI: GET the information from the form
        $n = $_POST["email"];
        $i = $_POST["password"];

        // 2. DB: connect to database

        // ----------------------------------------

      	$dbhost = "localhost";
      	$dbuser = "root";
      	$dbpassword = "";
      	$dbname = "airbnb";

      	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

      	// SQL QUERY:
        $query = 'SELECT * FROM user_data where email="'
                . $n
                . '" and password="'
                . $i
                . '"';

        //echo "Query you are sending to db: " . $query  . "<br>";
	$results = mysqli_query($conn, $query);

        // 3. LOGIC: check if user is in the database
        // If in db, $y = 0
        // Otherwise, $y = 1
        $y = mysqli_num_rows($results);
      //  echo "Number of rows returned: " . $y . "<br>";
	if($y == 1)
	{
		
		$id = $_SESSION['email']=$_POST['email'];
		header('location:login.php');
		
	}
	else
	{
		echo'Incorrect email or password!';
	}
}

?>