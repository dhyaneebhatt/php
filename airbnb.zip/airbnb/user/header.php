<?php
   if (session_status() == PHP_SESSION_NONE)
    {
      session_start();
   }
 
?>
<!DOCTYPE html>
<html>
   <head>
     
  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title>AirBNB</title>
  <meta name="description" content="This is a copy of airbnb website">
  <meta name="Simmy" content="">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/navigation.css">
  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/airbnbfavicon.png">

  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
<?php 

	if(isset($_SESSION['email']))
	{
		
	}
	else
	{
	
		session_start();
	}

?>
</head>

<body>

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <!--Navigation-->
  <div class="band navigation">
      <nav class="container primary">
          <div class="six columns">
              <ul class="navbar-right">
                 
     <?php
	 
	 //echo $_SESSION['email'];
                        if (isset($_SESSION['email']))
						 {
						
							echo '<li><a class="navbar-item" href="home.php">';
                            echo "Home";
                            echo "</a></li>";
							echo '<li><a class="navbar-item" href="search.php">';
                            echo "Search";
                            echo "</a></li>";
					 		echo '<li><a class="navbar-item" href="logout.php">';
                            echo "Logout";
                            echo "</a></li>";
							   
                        }
						else
						{
						   echo'<li><a href="index.php">';
							 echo"AirBnb";
						 	echo "</a></li>";
                           echo '<li><a href="login.php">';
                           echo "Log in";
                           echo "</a></li>";
						   echo '<li><a href="signup.php">';
                           echo 'Sign up';
                           echo '</a></li>';
						 
                             
                        }
      ?>
  				</ul>
          </div>
      </nav>
  </div>
         <!--       </div>
               </div>
            </div>
         </div>
      </nav>
      <!-- // end Navbar section -->
