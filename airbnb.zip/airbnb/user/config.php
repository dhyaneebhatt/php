<?php
//check if session is not there than 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// connect to the database

$dbhost = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "airbnb";
$db = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

?>
