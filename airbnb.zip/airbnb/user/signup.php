<!DOCTYPE html>

<html>

<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title>AirBNB</title>
  <meta name="description" content="This is a copy of airbnb website">
  <meta name="Simmy" content="">

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/navigation.css">
  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/airbnbfavicon.png">
  <!-- bulmA-->
<script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>

</head>

<body>
  <?php include("header.php"); ?>

  <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
	{

        // 1. UI: GET the information from the form
        $n = $_POST["email"];
        $i = $_POST["password"];
		$f = $_POST["fname"];
		$l=$_POST["lname"];
        // 2. DB: connect to database

        // ----------------------------------------

      	$dbhost = "localhost";
      	$dbuser = "root";
      	$dbpassword = "";
      	$dbname = "airbnb";

      	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

      	// SQL QUERY:
        $query = 'SELECT * FROM user_data where email="'
                . $n
                . '" and password="'
                . $i
                . '"';

        //echo "Query you are sending to db: " . $query  . "<br>";
	$results = mysqli_query($conn, $query);

        // 3. LOGIC: check if user is in the database
        // If in db, $y = 0
        // Otherwise, $y = 1
        $y = mysqli_num_rows($results);
      //  echo "Number of rows returned: " . $y . "<br>";

        if ($y == 0)
        {
            // 4. he is not in the db, so show an error message
            echo "<span style='color:red'>Invalid user or password! </span><br>";

        }
        else if($n == "a@admin.com")
		{
            // 5. set a session variable to show the admin is logged in
           // session_start();
            $_SESSION["adminLoggedIn"] = true;
            $_SESSION["email"] = "$n";
            $_SESSION["password"] = "$i";
			
            //  print_r($_SESSION["name"]);
            $_SESSION["key"] = md5($_SESSION["email"],FALSE);

            // 6. redirect them to page 2
           header("Location: ../admin/index.php?id=1");
          }
		  else
		  {
		  	// 5. set a session variable to show the user is logged in
           // session_start();
            $_SESSION["userLoggedIn"] = true;
            $_SESSION["email"] = "$n";
            $_SESSION["password"] = "$i";
			
            //  print_r($_SESSION["name"]);
            $_SESSION["key"] = md5($_SESSION["email"],FALSE);

            // 6. redirect them to page 2
           header("Location: search.php");
		  }
}
?>

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <!--Navigation-->

<div class="container">
    <div class="row">
      <div class="one-third column wide">
        <div class="boxes">
          <div class="headerpull">
          <h4>Sign up</h4>
         
       	 </div>
           <form>
            <div class="field">
 				 <p class="control has-icons-left has-icons-right">
   				 	<input class="input" type="email" placeholder="Email">
   					 <span class="icon is-small is-left">
     					 
    					</span>
			</p>
		</div>
		<div class="field">
 				 <p class="control has-icons-left">
   				 	<input class="input" type="fname" placeholder="First name">
   					 <span class="icon is-small is-left">
     				
    					</span>
			</p>
		</div>
		<div class="field">
 				 <p class="control has-icons-left">
   				 	<input class="input" type="lname" placeholder="Last name">
   					 <span class="icon is-small is-left">
     					
    					</span>
			</p>
		</div>
		<div class="field">
 				 <p class="control has-icons-left">
   					 <input class="input" type="password" placeholder="Password">
    					<span class="icon is-small is-left">
     					
   					</span>
				</p>
	  </div>
	  <h5>Allready have an account?<a href="login.php">Login</a></h5>
          </form>
        </div>
      </div>
    </div>
  </div>

</body>

</html>
