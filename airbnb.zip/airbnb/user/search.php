<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="grid.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/animations.css">
  <link rel="stylesheet" href="animate.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="style.css">
  <title>Airbnb</title>
</head>

<body>
  <nav class="navbar nav-one">
      <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"><img src="images/logo_airbnb.png" alt="Logo Airbnb"></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->

          <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
              <li><a href="#">Become a Host</a></li>
              <li><a href="#">Help</a></li>
              <li><a href="#">Registration</a></li>
              <li><a href="#">Log In</a></li>
            </ul>
          </div>
      </div>
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container-fluid -->
    </nav>
	
	<div class="span-12-of-12">
    <div class="section span-12-of-12 block3">
      <div class="span-10-of-12 block3-1">
        <div class="block3-1-1">
          <h3 class="span-2-of-10">Private Rooms</h3>
          
        </div>
		
        <div class="block3-2">
		<?php
			 while( $x = mysqli_fetch_assoc($results) ) {

					?>
          <div class="block3-2-1 col span-1-of-5">
		  
            <a href="#"><img src="03-01.jpg" alt="" class="span-5-of-5 image"></a>
            <a href="#"><span id="price"><?php  echo $x["Price"] ; ?></span><?php  echo $x["Name"]; ?> 
       
          </div>
		  <?php } ?>
		  </div>	 
        </div>
		
      </div> 
    </div> 	 