<!DOCTYPE html>
<html>

<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta charset="utf-8">
  <title>AirBNB</title>
  <meta name="description" content="This is a copy of airbnb website">
  <meta name="Simmy" content="">
  

  <!-- Mobile Specific Metas
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- FONT
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">

  <!-- CSS
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/navigation.css">
  <!-- Favicon
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <link rel="icon" type="image/png" href="images/airbnbfavicon.png">
  <!-- bulmA-->
<script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>

</head>

<body>
  <?php include("header.php"); 
  ?>
  
  
  

  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
  <!--Navigation-->

<div class="container">
    <div class="row">
      <div class="one-third column wide">
        <div class="boxes">
          <div class="headerpull">
          <h4>Login</h4>
         
       	 </div>
           <form  method="post" action="loginprocess.php">
            <div class="field">
 				 <p class="control has-icons-left has-icons-right">
   				 	<input class="input" type="email" placeholder="Email" name="email">
   					 <span class="icon is-small is-left">
     					 <i class="fas fa-envelope"></i>
    					</span>
				</p>
			</div>
			<div class="field">
 				 <p class="control has-icons-left">
   					 <input class="input" type="password" placeholder="Password" name="password">
    					<span class="icon is-small is-left">
     					 <i class="fas fa-lock"></i>
   					</span>
				</p>
		</div>
		<button type="submit" class="button" name="login">Login</button>
		<h5>Don't have an account?<a href="signup.php">Sign up</a></h5>
          </form>
        </div>
      </div>
    </div>
  </div>

</body>

</html>
