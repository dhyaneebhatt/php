-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2018 at 04:44 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `airbnb`
--

-- --------------------------------------------------------

--
-- Table structure for table `room_data`
--

CREATE TABLE `room_data` (
  `ID` varchar(2) DEFAULT NULL,
  `Name` varchar(52) DEFAULT NULL,
  `Type` varchar(18) DEFAULT NULL,
  `Location` varchar(8) DEFAULT NULL,
  `Price` varchar(5) DEFAULT NULL,
  `Rating` varchar(6) DEFAULT NULL,
  `Number of Reviews` varchar(17) DEFAULT NULL,
  `Superhost` varchar(9) DEFAULT NULL,
  `Owner` varchar(7) DEFAULT NULL,
  `Guests` varchar(6) DEFAULT NULL,
  `Bedrooms` varchar(8) DEFAULT NULL,
  `Beds` varchar(4) DEFAULT NULL,
  `Bath` varchar(4) DEFAULT NULL,
  `Free Cancellation` varchar(17) DEFAULT NULL,
  `Description` varchar(498) DEFAULT NULL,
  `Free Parking` varchar(12) DEFAULT NULL,
  `Laptop friendly` varchar(25) DEFAULT NULL,
  `Laundry` varchar(7) DEFAULT NULL,
  `Wifi` varchar(4) DEFAULT NULL,
  `Kitchen` varchar(7) DEFAULT NULL,
  `Cable TV` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `room_data`
--

INSERT INTO `room_data` (`ID`, `Name`, `Type`, `Location`, `Price`, `Rating`, `Number of Reviews`, `Superhost`, `Owner`, `Guests`, `Bedrooms`, `Beds`, `Bath`, `Free Cancellation`, `Description`, `Free Parking`, `Laptop friendly`, `Laundry`, `Wifi`, `Kitchen`, `Cable TV`) VALUES
('1', 'Sun Filled Photographic Hard Loft', 'Entire Loft', 'Toronto', '210', '5', '245', 'yes', 'Leslie', '2', '0', '1', '1', 'yes', 'Sunny Authentic Hard Loft. Voted \'Top Ten Airbnb Listings in Toronto,\' and featured in Toronto Life Magazine, \'Airbnb of the Week.\'\n\nHigh ceilings/ huge windows. Southern/ Eastern exposures. Brick walls/ wood floors. Top floor, corner unit. Heintzman Piano. Swing. Tons of natural light. Enquire for photo shoot rates.', 'no', 'yes', 'yes', 'yes', 'yes', 'yes'),
('2', 'Stylish Loft! Steps to Trendy King & Queen West', 'Entire Loft', 'Toronto', '205', '5', '128', 'no', 'Paul', '4', '2', '2', '1', 'no', 'This bohemian style artist\'s loft space has tons of character. Tucked away in a 150-year-old historical casket factory, the building has been converted into unique studio spaces for artists and creatives of all sorts! Truly the last of its kind in the downtown core, conveniently located in the King West 10-minute walk to CN Tower/Rogers center, Queen West, King West, Kensington market and the Waterfront! Very accessible to Billy Bishop, Pearson and easy TTC access!', 'no', 'yes', 'no', 'yes', 'yes', 'no'),
('3', 'Stylish Downtown Cosy Room', 'Private Room', 'Toronto', '61', '4.5', '241', 'no', 'Jenelle', '1', '1', '1', '2', 'yes', 'This is a lovely private room with one bed. \nThis a beautifully renovated 1890\'s Victorian townhome that is located in one of the major up and coming neighbourhoods in the city and walking distance to all downtown attractions and amenities. We have four guest bedrooms, Which offers a great opportunity to meet and chat with other people from all over the world.', 'no', 'yes', 'yes', 'yes', 'yes', 'no'),
('4', 'Genuine Hard Loft in Historic Building', 'Entire Apartment', 'Toronto', '148', '5', '529', 'yes', 'Pritesh', '2', '0', '1', '1', 'yes', 'Open concept industrial loft, this artist studio features 12\' ceilings, state of the art kitchen, concrete floors, boutique style bathroom,indoor parking and 24h security. \nThe loft is located in a vibrant neighbourhood, within walking distance from the Distillery District, the beaches, Opera House and great restaurants.', 'yes', 'yes', 'no', 'yes', 'yes', 'yes'),
('5', 'Downtown, Convenient, and Modern Apt', 'Private Room', 'Toronto', '29', '4.5', '76', 'no', '', '2', '1', '1', '1', 'yes', 'We offer a nice, modern and clean room with a Queen-sized mattress, new furniture with a built-in closet which having enough space for your belongings and luggage. You’ll love my place because of the convenience. Our place is 2-3 mins walk from Pape Station (350m). Every needed store is walking distance. Great bars and pubs are one block away. My place is good for couples, solo adventurers, business travellers, and furry friends (pets)', 'yes', 'yes', 'yes', 'yes', 'yes', 'no'),
('6', 'Luxurious Executive-Style Condo in Central Toronto', 'Entire Condominium', 'Toronto', '182', '5', '10', 'no', '', '5', '1', '3', '1', 'yes', 'The condo is right in the heart of Toronto\'s Entertainment District. From mighty Lake Ontario to the heights of the CN tower, and from Ripley\'s Aquarium to the cheering crowds at Rogers Center, the city\'s best sights are just a stone\'s throw away.', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes'),
('7', 'Toronto Tree Top Room', 'Private Room', 'Toronto', '45', '5', '65', 'no', '', '2', '1', '1', '1', 'yes', 'Bright, cozy room in a flat near universities and colleges. 3 minutes from the subway in downtown Toronto. Walking distance to galleries, restaurants, museums, theatres, cultural centres and more!', 'no', 'no', 'no', 'yes', 'no', 'no'),
('8', 'Kensington Market, Sleeps 4!', 'Entire Apartment', 'Toronto', '87', '4', '93', 'no', '', '4', '0', '2', '1', 'yes', 'KENSINGTON MARKET!!\nAMAZING LOCATION!!\n\nYou will be living in the heart of Kensington Market, groceries, restaurants, bars, shops.', 'no', 'yes', 'no', 'yes', 'yes', 'no'),
('9', 'Panoramic View, Downtown Toronto, Liberty Village!', 'Entire Apartment', 'Toronto', '154', '5', '9', 'no', '', '2', '1', '1', '1', 'yes', 'In the heart of Liberty Village, Williams Landing, Tim Hortons, Brazen Head, CIBC, TD, Exhibition, BMO Field, Lake Ontario, TTC (15 Min to Bloor), Metro, Close to Downtown, Toronto Island, Access to Gardiner and Lakeshore, King and Queen West shopping/Clubs.\n\nEnjoy Panoramic views of downtown and Lake Ontario, the average age of LV is 28. Ceiling to floor Windows, South/East Facing Balcony, Mid Century Modern decor, Private Bathroom. Good for couples, solo adventurers, and business travellers.', 'yes', 'yes', 'no', 'yes', 'yes', 'yes'),
('10', 'Affordable stay in Downtown Toronto', 'Private Room', 'Toronto', '36', '4', '233', 'no', '', '3', '1', '1', '1', 'yes', 'A beautiful, furnished, one bedroom in a semi detached house located between The Annex & Little italy.', 'no', 'no', 'no', 'yes', 'yes', 'no'),
('11', 'Quaint Victorian Rowhouse Downtown Toronto', 'Private Room', 'Toronto', '68', '5', '138', 'no', '', '2', '1', '1', '1', 'yes', 'Conveniently walkable to Yonge & Dundas, the Distillery district, Leslieville, Cabbagetown and many TIFF venues. SO many fab restaurants nearby and any 1 of 3 streetcars can take you to the other side of the city. Parking on premises possible but not guaranteed. Check-in depends on the day...give me your estimated time of arrival and I will let you know if I can accommodate.\n\nNo microwave or access to cooking, but fridge, kettle & toaster are at your disposal.', 'no', 'yes', 'no', 'yes', 'no', 'no'),
('12', 'Explore Toronto from a Renovated Studio', 'Private Room', 'Toronto', '133', '5', '227', 'no', '', '2', '0', '1', '1', 'yes', 'This is an updated studio apartment within a home. It is a basement suite with own separate entrance and its own kitchen bathroom ect.\n\nThere is an eat in kitchen with new appliances. The apartment is the basement to my other listing on here and the only shared space is the Laundry room. There is a 42inch flat screen tv with cable, along with wifi included. There is a dresser and a place to hang clothing.', 'no', 'no', 'yes', 'no', 'yes', 'yes'),
('13', 'Luxury Downtown Toronto 1 Bedroom Suite', 'Entire Apartment', 'Toronto', '106', '4.5', '10', 'no', '', '2', '1', '1', '1', 'yes', 'Cozy Private apartment just for you in the heart of one of the most vibrant neighborhoods Toronto has to offer, Little Italy. 5 mins short walk to Bathurst subway station which takes you anywhere in the city.\n\nThis lively neighborhood is packed with trattorias, trendy restaurants, cafés, pool halls and some of the best bars in town. It\'s sidewalks are humming with activity on weekends, especially when the weather turns cozy, with locals and visitors alike sipping espresso on outdoor patios.', '', 'yes', 'yes', 'yes', 'yes', 'yes'),
('14', 'Studio Apartment in Little Italy', 'Entire Apartment', 'Toronto', '135', '5', '29', 'no', '', '2', '1', '1', '1.5', 'yes', 'A spacious bedroom with two large windows in the heart of midtown Toronto in a beautifully, freshly renovated apartment. Steps away from the bus stop, 5 mins walk to subway, restaurants, Yorkdale Mall, 15 mins to downtown via subway, and easy access to absolutely every convenience you can think of.', 'no', 'yes', 'yes', 'yes', 'yes', 'yes'),
('15', 'Scenic Master Bedroom with Bath, Balcony, and Closet', 'Private Room', 'Toronto', '114', '5', '84', 'no', '', '2', '1', '1', '2', 'yes', 'Unobstructed waterfront view and great location - walking distance from all major attractions in the downtown core. 5 minute walk to: Union Station, Air Canada Centre, Rogers Centre, Metro Toronto Convention Centre, Westin Harbour Castle, Toronto Islands Ferry, Entertainment District, CN Tower.', 'no', 'yes', 'yes', 'yes', 'no', 'no'),
('16', 'Simple and Affordable Room ', 'Private Room', 'Toronto', '56', '5', '619', 'yes', '', '3', '1', '1', '1', 'yes', 'Flexible check in/out, staying with me in top floor (24 stairs up) 40 year old sunny townhouse complex: 650 square feet electric heating. 8 mins from downtown by 24 hour transit/bike; 25 mins walk). A few small shops/restaurants nearby: sushi, greek, ethiopian, breakfast. lgbt positive. I cherish guests\' suggestions. Corktown neighbourhood is east of downtown, slowly growing, eclectic, working class and safe. Parking is behind the complex just 50 metres away. Anything you need, just ask!', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes'),
('17', '1B+Den Lakeview New Condo Air Canada Center', 'Entire Apartment', 'Toronto', '125', '5', '61', 'no', '', '4', '1', '2', '1', 'yes', 'This extraordinary new condo is in the heart of Toronto. It has been newly furnished with beautiful chandeliers, stone wall, accessories, extra lighting & furniture. Also with a large corner balcony you get some great views within the city and lake. Its location is very rare as it is one of the few roads in Toronto that connects the Rogers Centre, Ripley\'s aquarium and Air Canada Centre. It is a great spot if you are attending these venues as well as anything in Toronto\'s downtown core.', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE `user_data` (
  `id` int(5) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`id`, `email`, `password`, `fname`, `lname`) VALUES
(2, 'a@gmail.com', 'test', 'customer1', 'abc'),
(3, 'b@gmail.com', 'test', 'customer2', 'def'),
(6, 'alaydesai094@gmail.com', '123', 'Alay', 'Desai'),
(7, 'shivam@admin', '123', 'shivam', 'bhatt');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_data`
--
ALTER TABLE `user_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_data`
--
ALTER TABLE `user_data`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
