<!DOCTYPE html>
<html>
<head>
<title>Final Test</title>
	 <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
	 <link rel="stylesheet" href="final.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 	<script src="https://use.fontawesome.com/7ffe815bc9.js"></script>
	 <link rel="stylesheet" type="text/css" href="admin.css">
	  <script type="text/javascript" src="admin.js"></script>


</head>
<body>
	<?php include 'header.php';?>
 
 <?php

  if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // 1. Get the data from the form url
     $pos =  $_GET["pos"];
	 echo $pos;
	
	$sql = "DELETE FROM room_data WHERE ID = '$pos'" ;
	
	// Execute query
	   $results = mysqli_query($conn, $sql);
	if($results)
	{
		echo "Deleted Successfully";
		header('location:index.php'); 
	}
	else
	{
		echo "Not Deleted";
	}
}
?>





	      
    </div>
  </div>
</div>

  
  </div>
</div>
 <script type="text/javascript" src="admin.js"></script>

</div> <!---Cointainer--->
</body>
</html>