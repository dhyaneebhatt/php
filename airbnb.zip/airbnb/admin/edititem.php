<!DOCTYPE html>
<html>
<head>
<title>Final Test</title>
	 <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
	 <link rel="stylesheet" href="final.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 	<script src="https://use.fontawesome.com/7ffe815bc9.js"></script>
	 <link rel="stylesheet" type="text/css" href="admin.css">
	  <script type="text/javascript" src="admin.js"></script>


</head>
<body>
	<?php include 'header.php';?>
 
 <?php

  if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // 1. Get the data from the form url
     $pos =  $_GET["pos"];
	 echo $pos; 
// Insert data into the db
    $sql = "SELECT * FROM room_data WHERE ID = '".$pos."' ";
    $results = mysqli_query($conn, $sql);
	$x = mysqli_fetch_assoc($results);


?> 
  <!--- Data Show--->
  
  <div class="column" style=" width:90% ;overflow: auto; white-space: nowrap;" >
  <div class="tile is-parent" >
    <div class="tile is-child box">
	
	<form action="edititem.php" method="POST">
	
	  <div class="notification" style="width:809px ; margin-top:60px; margin-left:100px" >
   <label class="label" style="font-size:20px; margin-bottom:30px"><center>Add New Item </center></label>
<div class="field" >
  <label class="label">Name</label>
  <div class="control">
    <input class="input" type="text" id="Name" name="Name" value="<?php echo $x['Name']; ?>">
  </div>
</div>
<br>
<div class="field">
<label class="label">Type</label>
  <div class="control">
  <label class="radio">
	<input type="radio" name="Type"   value="Private Room"> 
    Private Room
  </label>
  <label class="radio">
    <input type="radio" name="Type"   value ="Entire Loft">
   Entire Loft
  </label>
  </label>
  <label class="radio">
    <input type="radio" name="Type" value= "Entire Condominium" >
   Entire Condominium
  </label>
  </label>
  <label class="radio">
    <input type="radio" name="Type" value= "Entire Apartment" >
   Entire Apartment
  </label>
</div>
<br>
<div class="field is-grouped" >

<div class="field" >
  <label class="label">Location</label>
  <div class="control">
    <input class="input" type="text" id="Location" name="Location" value="<?php echo $x["Location"] ; ?>">
  </div>
</div>
<div class="field" >
  <label class="label">Price</label>
  <div class="control">
    <input class="input" type="text" id="Price" name="Price" value="<?php echo $x["Price"] ; ?>">
  </div>

</div>

<div class="field is-grouped" >

<div class="field" >
  <label class="label">Rating</label>
  <div class="control">
    <input class="input" type="text" id="Rating" name="Rating" value="<?php echo $x["Rating"] ; ?>">
  </div>
</div>
</div>
<div class="field" >
  <label class="label">Number of Reviews</label>
  <div class="control">
    <input class="input" type="text" id="Number_of_Reviews" name="Number_of_Reviews" value="<?php echo $x["Number of Reviews"] ; ?>">
  </div>
</div>

</div>

<div class="field" >
  <label class="label">Superhost</label>
  <div class="control">
    <input class="input" type="text" id="Superhost" name="Superhost" value="<?php echo $x["Superhost"] ; ?>">
  </div>
</div>

<div class="field is-grouped" >

<div class="field" >
  <label class="label">Owner </label>
  <div class="control">
    <input class="input" type="text" id="Owner" name="Owner" value="<?php echo $x["Owner"] ; ?>">
  </div>
</div>

<div class="field" >
  <label class="label">Guests</label>
  <div class="control">
    <input class="input" type="text" id="Guests" name="Guests" value="<?php echo $x["Guests"] ; ?>">
  </div>
</div>

</div>

<div class="field is-grouped" >

<div class="field" >
  <label class="label">Bedrooms</label>
  <div class="control">
    <input class="input" type="text" id="Bedrooms" name="Bedrooms" value="<?php echo $x["Bedrooms"] ; ?>">
  </div>
</div>

<div class="field" >
  <label class="label">Beds</label>
  <div class="control">
    <input class="input" type="text" id="Beds" name="Beds" value="<?php echo $x["Beds"] ; ?>">
  </div>
</div>

<div class="field" >
  <label class="label">Bath</label>
  <div class="control">
    <input class="input" type="text" id="Bath" name="Bath" value="<?php echo $x["Bath"] ; ?>">
  </div>
</div>

</div>

<div class="field is-grouped" >

<div class="field" >
  <label class="label">Free Cancellation </label>
  <div class="control">
    <input class="input" type="text" id="Free_Cancellation" name="Free_Cancellation" value="<?php echo $x["Free Cancellation"] ; ?>">
  </div>
</div> 

<div class="field" >
  <label class="label">Description</label>
  <div class="control">
    <input class="input" type="text" id="Description" name="Description" value="<?php echo $x["Description"] ; ?>">
  </div>
</div> 

<div class="field" >
  <label class="label">Free Parking</label>
  <div class="control">
    <input class="input" type="text" id="Free_Parking" name="Free_Parking" value="<?php echo $x["Free Parking"] ; ?>">
  </div>
</div> 

</div>

<div class="field is-grouped" >

<div class="field" >
  <label class="label">Laptop Friendly</label>
  <div class="control">
    <input class="input" type="text" id="Laptop_Friendly" name="Laptop_Friendly" value="<?php echo $x["Laptop friendly"] ; ?>">
  </div>
</div> 

<div class="field" >
  <label class="label">Laundry</label>
  <div class="control">
    <input class="input" type="text" id="Laundry" name="Laundry" value="<?php echo $x["Laundry"] ; ?>">
  </div>
</div> 

<div class="field" >
  <label class="label">Wifi</label>
  <div class="control">
    <input class="input" type="text" id="Wifi" name="Wifi" value="<?php echo $x["Wifi"] ; ?>">
  </div>
</div>
 
<div class="field" >
  <label class="label">Kitchen</label>
  <div class="control">
    <input class="input" type="text" id="Kitchen" name="Kitchen" value="<?php echo $x["Kitchen"] ; ?>">
  </div>
</div> 

<div class="field" >
  <label class="label">Cable TV</label>
  <div class="control">
    <input class="input" type="text" id="Cable_TV" name="Cable_TV" value="<?php echo $x["Cable TV"] ; ?>">
  </div>
</div>

</div>

<div class="field" >
  <label class="label"></label>
  <div class="control">
    <input class="input" type="hidden" id="Type" name="Type" value="<?php echo $x["Type"] ; ?>">
  </div>
</div>

<div class="field" >
  <label class="label"></label>
  <div class="control">
    <input class="input" type="hidden" id="ID" name="ID" value="<?php echo $x["ID"] ; ?>">
  </div>
</div>

<div class="field is-grouped">
  <div class="control">
    <button class="button is-primary is-rounded" name="Save" id ="Save">Save</button>
  </div>
  <div class="control">
    <button class="button is-danger is-rounded">Cancel</button>
  </div>
</div>

 </div>
</form>
<?php
  }

?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Get the data from the form
  
     $ID =  $_POST["ID"];
	 //echo $ID; 
     $Name =  $_POST["Name"];
	 //echo $Name; 
	 $Type =  $_POST["Type"];
	 //echo $Type; 
	  $Location =  $_POST["Location"];
	  //echo $Location;
	   $Price =  $_POST["Price"];
	   //echo $Price;
	    $Rating =  $_POST["Rating"];
		//echo $Rating;
		 $Number_of_Reviews =  $_POST["Number_of_Reviews"];
		 //echo $Number_of_Reviews;
		 $Superhost =  $_POST["Superhost"];
		// echo $Superhost;
  		$Owner =  $_POST["Owner"];
		//echo $Owner;
    		$Guests =  $_POST["Guests"];
		//echo $Guests; 
    		$Bedrooms =  $_POST["Bedrooms"];
		//echo $Bedrooms; 
	 	$Beds =  $_POST["Beds"];
		//echo $Beds;
	  	$Bath =  $_POST["Bath"];
		//echo $Bath; 
	   	$Free_Cancellation =  $_POST["Free_Cancellation"];
		//echo $Free_Cancellation;
	    $Description =  $_POST["Description"];
		//echo $Description;
		$Free_Parking =  $_POST["Free_Parking"];
		//echo $Free_Parking;
		$Laptop_Friendly  =  $_POST["Laptop_Friendly"];
		//echo $Laptop_Friendly;
		$Laundry =  $_POST["Laundry"];
		//echo $Laundry ;
		$Wifi =  $_POST["Wifi"];
		//echo $Wifi;
		$Kitchen =  $_POST["Kitchen"];
		//echo $Kitchen; 
		$Cable_TV =  $_POST["Cable_TV"];	
		//echo $Cable_TV;
		
		
$sql= "update room_data set
 Name='$Name', Type = '$Type', Location = '$Location', Price = '$Price', Rating = '$Rating', 
Number of Reviews='$Number_of_Reviews',Superhost='$Superhost', Owner='$Owner', Guests='$Guests', 
Bedrooms='$Bedrooms', Superhost='$Superhost', Beds='$Beds', Bath='$Bath',Free Cancellation='$Free_Cancellation',
 Description='$Description', Free Parking='$Free_Parking', Laptop friendly='$Laptop_Friendly',Laundry='$Laundry',
  Wifi='$Wifi',Kitchen='$Kitchen',Cable TV='$Cable_TV' where ID= '$ID'  ";
	
	// Execute query
	   $results = mysqli_query($conn, $sql);
	if($results)
	{
		echo "Updated";
		header('location:admin/edititem.php'); 
	}
	else
	{
		echo "Not Updated";
	}
		
		
		
}
?>





	      
    </div>
  </div>
</div>

  
  </div>
</div>
 <script type="text/javascript" src="admin.js"></script>

</div> <!---Cointainer--->
</body>
</html>