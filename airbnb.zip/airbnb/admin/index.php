<!DOCTYPE html>
<html>
<head>
<title>Final Test</title>
	 <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
	 <link rel="stylesheet" href="final.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 	<script src="https://use.fontawesome.com/7ffe815bc9.js"></script>
	 <link rel="stylesheet" type="text/css" href="admin.css">
	  <script type="text/javascript" src="admin.js"></script>
	  
	</head>  
	<body>
	<?php include 'header.php';?>
	
	<?php  
		$query = 'SELECT * FROM room_data ';
 		$results = mysqli_query($conn, $query);
		$rows = mysqli_num_rows($results);
  ?>
  <!--- Data Show--->
  
  <div class="column" style=" width:90% ;overflow: auto; white-space: nowrap;" >
  <div class="tile is-parent" >
    <div class="tile is-child box">
	
	
	
	
			<!--- Table Content --->
	  <table class="table"  >
  <thead>
  		<tr> Total <?php echo "$rows";  ?> Entries Found </tr>
  </thead>
  <thead>
    <tr>
     <th name="id">ID</th>
      <th name="Name">Name</th>
	   <th name="Type">Type</th>
		<th name="Location">Location</th>
		<th name="Price">Price</th>
		<th name="Rating">Rating</th>
	    <th name="Number of Reviews">Number of Reviews</th>
	    <th name="Superhost">Superhost</th>
  		<th name="Owner">Owner</th>
        <th name="Guests">Guests</th>
	    <th name="Bedrooms">Bedrooms</th>
		 <th name="Beds">Beds</th>
        <th name="Bath">Bath</th>
        <th name="Free Cancellation">Free Cancellation</th>
        <th name="Description">Description</th>
		 <th name="Free Parking">Free Parking</th>
		 <th name="Laptop friendly workspace">Laptop friendly workspace</th>
     	 <th name="Laundry">Laundry</th>
		 <th name="Wifi">Wifi</th>
		<th name="Kitchen">Kitchen</th> 
	    <th name="Cable TV">Cable TV</th>
		<th name="edit">Edit</th>
		<th name="Delete">Delete</th>
    </tr>
  </thead>
  
  <?php
 while( $x = mysqli_fetch_assoc($results) ) {
?>
  <tbody>
    <tr>
      <th><?php echo $x["ID"] ; ?> </th>
      <td><?php echo substr($x["Name"],0,20) . "..."  ;  ?> </td>
      <td><?php echo $x["Type"] ; ?></td>
      <td><?php echo $x["Location"]; ?></td>
      <td><?php echo $x["Price"]; ?></td>
      <td><?php echo $x["Rating"]; ?></td>
      <td><?php echo $x["Number of Reviews"]; ?></td>
      <td><?php echo $x["Superhost"] ; ?></td>
      <td><?php echo $x["Owner"] ; ?></td>
	    <td><?php echo $x["Guests"] ; ?></td>
		  <td><?php echo $x["Bedrooms"]; ?></td>
		    <td><?php echo $x["Beds"] ; ?></td>
			  <td><?php echo $x["Bath"]; ?></td>
			    <td><?php echo $x["Free Cancellation"]; ?></td>
				  <td><?php echo substr($x["Description"],0,10) . "..."  ; ?></td>
				    <td><?php echo $x["Free Parking"] ; ?></td>
					  <td><?php echo $x["Laptop friendly"] ; ?></td>
					    <td><?php echo $x["Laundry"] ; ?></td>
						    <td><?php echo $x["Wifi"] ; ?></td>
							    <td><?php echo $x["Kitchen"]; ?></td>
								    <td><?php echo $x["Cable TV"]; ?></td>
									    <td><?php   echo '<a href="edititem.php?pos='.$x["ID"].'">Edit</a> ';?></td>
										 <td><?php   echo '<a href="deleteitem.php?pos='.$x["ID"].'">Delete</a> ';?></td>
									
									<?php
       
      }


?>

    </tr>

  </tbody>
</table>
	      
    </div>
  </div>
</div>

  
  </div>
</div>
 <script type="text/javascript" src="admin.js"></script>

</div> <!---Cointainer--->
</body>
</html>